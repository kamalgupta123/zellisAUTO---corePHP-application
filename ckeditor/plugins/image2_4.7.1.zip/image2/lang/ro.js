/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ro', {
	alt: 'Text alternativ',
	btnUpload: 'Trimite la server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Informaţii despre imagine',
	lockRatio: 'Păstrează proporţiile',
	menu: 'Proprietăţile imaginii',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Resetează mărimea',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Proprietăţile imaginii',
	uploadTab: 'Încarcă',
	urlMissing: 'Sursa URL a imaginii lipsește.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
